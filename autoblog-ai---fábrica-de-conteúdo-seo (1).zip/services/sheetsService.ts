
/**
 * Mock Service para simular a interação com o Google Apps Script
 */
export const syncHubWithSheets = async () => {
  console.log("Chamando Apps Script: doPOST(sync)...");
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true, message: "Hub sincronizado com sucesso." });
    }, 1500);
  });
};

export const triggerAutomation = async (rowId: string) => {
  console.log(`Triggering automation for row ${rowId} via Apps Script...`);
  // Aqui seriam feitas as chamadas via fetch para o Web App URL do Apps Script
  return { success: true };
};
