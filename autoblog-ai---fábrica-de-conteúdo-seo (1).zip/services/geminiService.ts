import { GoogleGenAI, Type, Modality } from "@google/genai";

const SITE_STRUCTURE = {
  internal_links: [
    { title: "Guia de Criomodelagem", url: "/procedimentos/criomodelagem-avancada", context: "gordura localizada, contorno corporal, resfriamento controlado" },
    { title: "Harmonização Facial", url: "/procedimentos/harmonizacao-facial-natural", context: "preenchimento, mandíbula, malar, estética facial" },
    { title: "Bioestimuladores de Colágeno", url: "/procedimentos/bioestimuladores-de-colageno", context: "flacidez, sustentação, radiesse, sculptra, bioestimulação" },
    { title: "Limpeza de Pele Profunda", url: "/procedimentos/limpeza-de-pele-profunda", context: "cravos, espinhas, renovação celular, detox facial" },
    { title: "Manual de Pós-operatório", url: "/cuidados/pos-operatorio-estetica", context: "recuperação, drenaem linfática, cuidados após cirurgia" },
    { title: "Avaliação Personalizada", url: "/contato/agendar-avaliacao", context: "consulta, agendamento, diagnóstico inicial" }
  ],
  external_authorities: [
    "SBD (Sociedade Brasileira de Dermatologia)",
    "SBCP (Sociedade Brasileira de Cirurgia Plástica)",
    "PubMed Central (Dados Científicos)",
    "Healthline (Referências de Bem-estar)",
    "WebMD (Informação Médica)"
  ]
};

// Inicialização segura do AI
const getAiClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// Gera conteúdo de blog otimizado com base em palavras-chave e tópicos
export const generateBlogContent = async (params: {
  keyword: string;
  topic: string;
  type: string;
  size: string;
  language: string;
}) => {
  const ai = getAiClient();
  const systemInstruction = `Você é o "Elevare Link Intelligence", um arquiteto de conteúdo SEO especializado em ESTÉTICA DE LUXO e SAÚDE ESTÉTICA.
    Seu objetivo é criar autoridade clínica. Use terminologia técnica correta (ex: derme, bioestimulação, subcutâneo).
    Integre links internos de forma orgânica: ${JSON.stringify(SITE_STRUCTURE.internal_links)}
    Cite autoridades externas quando necessário: ${SITE_STRUCTURE.external_authorities.join(', ')}`;

  const prompt = `Gere um artigo otimizado e luxuoso sobre: "${params.keyword}". 
    Tema: ${params.topic}. 
    Abordagem: ${params.type}. 
    Tamanho: ${params.size}.
    O conteúdo deve ser formatado em HTML limpo.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      thinkingConfig: { thinkingBudget: 4000 },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          slug: { type: Type.STRING },
          content: { type: Type.STRING },
          metaTitle: { type: Type.STRING },
          metaDescription: { type: Type.STRING },
          linkIntelligence: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                anchor: { type: Type.STRING },
                url: { type: Type.STRING },
                reason: { type: Type.STRING }
              }
            }
          }
        },
        required: ["title", "slug", "content", "metaTitle", "metaDescription", "linkIntelligence"]
      }
    }
  });

  return JSON.parse(response.text.trim());
};

// Gera imagens editoriais sofisticadas para os artigos
export const generateImage = async (prompt: string) => {
  const ai = getAiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: `High-end aesthetic clinic environment, sophisticated atmosphere, editorial medical photography, soft professional lighting, clean minimalist decor: ${prompt}` }]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9"
      }
    }
  });

  // Itera por todas as partes para encontrar a imagem retornada pelo modelo
  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }
  return null;
};

// Gera áudio profissional a partir do texto do blog
export const generateAudio = async (text: string) => {
  const ai = getAiClient();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Resumo profissional para blog de clínica estética: ${text.substring(0, 800)}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' } // Voz sofisticada e calma
        },
      },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

// Gera estrutura de dados para Web Stories baseada em um artigo
export const generateWebStoryData = async (title: string, content: string) => {
  const ai = getAiClient();
  const prompt = `Com base no artigo "${title}", crie 5 slides para um Web Story visual e dinâmico sobre estética. 
    Para cada slide, forneça: um título curto de impacto, um texto de apoio e uma descrição detalhada para geração de imagem.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          slides: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                text: { type: Type.STRING },
                imagePrompt: { type: Type.STRING }
              },
              required: ["title", "text", "imagePrompt"]
            }
          }
        },
        required: ["slides"]
      }
    }
  });
  return JSON.parse(response.text.trim());
};

// Corrige o erro: Module '"../services/geminiService"' has no exported member 'convertYoutubeToArticle'
export const convertYoutubeToArticle = async (url: string) => {
  const ai = getAiClient();
  const prompt = `Aja como um especialista em SEO e redação para clínicas de estética de luxo.
    Analise o conteúdo do vídeo do YouTube em: ${url}.
    Transforme o conteúdo do vídeo em um artigo de blog sofisticado, com estrutura de títulos (H2, H3), parágrafos envolventes e formatação HTML limpa.
    Foque em autoridade clínica e educação do paciente.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "Título otimizado do artigo" },
          content: { type: Type.STRING, description: "Conteúdo estruturado em HTML" }
        },
        required: ["title", "content"]
      }
    }
  });

  return JSON.parse(response.text.trim());
};
