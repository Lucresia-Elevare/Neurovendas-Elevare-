
import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Globe, 
  Database,
  Settings, 
  PlayCircle,
  Video,
  LogOut,
  Menu,
  X,
  Volume2,
  Sparkles,
  Youtube,
  Rocket,
  Search
} from 'lucide-react';
import { ICON_STYLES, APP_NAME } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  credits: number;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, credits }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className={ICON_STYLES} /> },
    { id: 'hub', label: 'Hub Operacional', icon: <Database className={ICON_STYLES} /> },
    { id: 'generator', label: 'Editorial AI', icon: <Sparkles className={ICON_STYLES} /> },
    { id: 'youtube', label: 'YouTube -> Post', icon: <Youtube className={ICON_STYLES} /> },
    { id: 'autopilot', label: 'Piloto Automático', icon: <Rocket className={ICON_STYLES} /> },
    { id: 'examples', label: 'Explorar Exemplos', icon: <Search className={ICON_STYLES} /> },
    { id: 'articles', label: 'Meus Artigos', icon: <FileText className={ICON_STYLES} /> },
    { id: 'stories', label: 'Web Stories', icon: <Video className={ICON_STYLES} /> },
    { id: 'training', label: 'Treinamento', icon: <PlayCircle className={ICON_STYLES} /> },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center font-serif italic font-bold">E</div>
        <h1 className="text-lg font-bold tracking-widest uppercase">{APP_NAME}</h1>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id);
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeTab === item.id 
              ? 'bg-indigo-600 text-white shadow-lg' 
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {item.icon}
            <span className="font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-2xl p-4 mb-4 border border-slate-700">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Créditos Elevare</span>
            <span className="text-xs font-bold text-indigo-400">{credits}/180</span>
          </div>
          <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full w-[78%]" />
          </div>
        </div>
        <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-rose-400 transition-colors text-sm font-bold">
          <LogOut className={ICON_STYLES} />
          Sair
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50">
      <div className={`fixed inset-0 z-50 lg:hidden transition-transform duration-300 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="absolute inset-0 bg-black/50" onClick={() => setIsSidebarOpen(false)} />
        <div className="relative w-72 h-full"><SidebarContent /></div>
      </div>

      <aside className="hidden lg:block w-72 h-screen sticky top-0 border-r border-slate-200">
        <SidebarContent />
      </aside>

      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-6 sticky top-0 z-40">
          <button className="lg:hidden p-2 text-slate-600" onClick={() => setIsSidebarOpen(true)}><Menu className="w-6 h-6" /></button>
          <div className="flex items-center gap-4 ml-auto">
             <div className="hidden sm:flex items-center gap-2 px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold border border-indigo-100">
                <Database className="w-3 h-3" /> Sheets Hub: Live
             </div>
             <img src="https://picsum.photos/seed/clinica/40/40" alt="User" className="w-8 h-8 rounded-full ring-2 ring-indigo-100" />
          </div>
        </header>

        <div className="p-6 max-w-7xl mx-auto w-full">{children}</div>
      </main>
    </div>
  );
};

export default Layout;
