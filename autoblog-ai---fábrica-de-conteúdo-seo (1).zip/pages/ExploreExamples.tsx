
import React from 'react';
import { Eye, FileText, Star, ArrowUpRight } from 'lucide-react';

const EXAMPLES = [
  {
    title: "O Guia Definitivo da Criomodelagem Avançada",
    type: "Guia de Procedimento",
    seo: 98,
    img: "https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&q=80&w=800",
    description: "Um artigo denso focado em intenção de compra e esclarecimento de dúvidas técnicas."
  },
  {
    title: "Bioestimuladores: Radiesse ou Sculptra?",
    type: "Comparativo de Autoridade",
    seo: 95,
    img: "https://images.unsplash.com/photo-1616391182219-e080b4d1043a?auto=format&fit=crop&q=80&w=800",
    description: "Análise científica comparativa para educar pacientes de alto ticket."
  },
  {
    title: "Como a Limpeza de Pele Mudou meu Pós-parto",
    type: "Relato Educativo",
    seo: 91,
    img: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&q=80&w=800",
    description: "Conteúdo focado em humanização e jornada emocional da cliente."
  }
];

const ExploreExamples: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header>
        <h1 className="text-3xl font-extrabold text-slate-900">Explore Exemplos Reais</h1>
        <p className="text-slate-500">Veja o nível de profundidade e SEO dos artigos gerados pela Elevare AI.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        {EXAMPLES.map((ex, i) => (
          <div key={i} className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-xl transition-all group">
            <div className="relative h-48 overflow-hidden">
              <img src={ex.img} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={ex.title} />
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest text-indigo-600">
                {ex.type}
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-slate-900 leading-tight flex-1 pr-4">{ex.title}</h3>
                <div className="flex items-center gap-1 text-emerald-600 font-bold text-sm">
                  <Star className="w-4 h-4 fill-current" /> {ex.seo}
                </div>
              </div>
              <p className="text-slate-500 text-sm line-clamp-2">{ex.description}</p>
              <button className="w-full py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-all">
                <Eye className="w-4 h-4" /> Visualizar Artigo Completo
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-indigo-900 p-10 rounded-3xl text-white text-center">
        <h2 className="text-2xl font-bold mb-4">Gostou da qualidade?</h2>
        <p className="text-indigo-200 mb-8 max-w-2xl mx-auto">Sua clínica pode ter 180 artigos como estes todos os anos, sem você escrever uma única linha.</p>
        <button className="px-8 py-4 bg-white text-indigo-900 rounded-2xl font-bold hover:shadow-2xl transition-all flex items-center gap-3 mx-auto">
          Começar minha Automação <ArrowUpRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default ExploreExamples;
