
import React, { useState } from 'react';
import { Youtube, Loader2, Sparkles, Send, FileText, CheckCircle2 } from 'lucide-react';
import { convertYoutubeToArticle } from '../services/geminiService';

const YoutubeConverter: React.FC = () => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [article, setArticle] = useState<any>(null);

  const handleConvert = async () => {
    setLoading(true);
    try {
      const result = await convertYoutubeToArticle(url);
      setArticle(result);
    } catch (e) {
      alert("Erro ao processar vídeo.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 mb-2">YouTube → Artigo</h1>
        <p className="text-slate-500">Transforme vídeos técnicos em conteúdo de autoridade para seu blog.</p>
      </header>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-rose-600">
              <Youtube className="w-6 h-6" />
            </div>
            <input 
              type="text" 
              placeholder="Cole a URL do vídeo do YouTube..."
              className="w-full pl-14 pr-4 py-5 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-rose-500 outline-none transition-all font-medium"
              value={url}
              onChange={e => setUrl(e.target.value)}
            />
          </div>
          <button 
            onClick={handleConvert}
            disabled={loading || !url}
            className="px-8 bg-indigo-900 text-white rounded-2xl font-bold hover:bg-indigo-950 transition-all flex items-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
            Converter
          </button>
        </div>
      </div>

      {article && (
        <div className="bg-white p-10 rounded-3xl border border-slate-200 shadow-sm space-y-8 animate-in fade-in zoom-in-95">
          <div className="flex justify-between items-center border-b border-slate-100 pb-6">
            <h2 className="text-2xl font-bold text-slate-900">{article.title}</h2>
            <div className="flex gap-2">
              <button className="px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold text-sm">Editar</button>
              <button className="px-4 py-2 bg-indigo-900 text-white rounded-xl font-bold text-sm flex items-center gap-2">
                <Send className="w-4 h-4" /> Publicar
              </button>
            </div>
          </div>
          <div 
            className="prose prose-indigo max-w-none text-slate-700 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: article.content }}
          />
        </div>
      )}

      {!article && !loading && (
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: <FileText className="w-6 h-6" />, title: "Estruturação Lógica", desc: "A IA identifica os tópicos principais e cria H2/H3 automaticamente." },
            { icon: <Sparkles className="w-6 h-6" />, title: "Otimização SEO", desc: "Inclui palavras-chave semânticas extraídas do áudio." },
            { icon: <CheckCircle2 className="w-6 h-6" />, title: "Pronto para Uso", desc: "Gera meta tags e sugestão de imagem editorial." }
          ].map((f, i) => (
            <div key={i} className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="text-indigo-600 mb-4">{f.icon}</div>
              <h4 className="font-bold text-slate-900 mb-1">{f.title}</h4>
              <p className="text-xs text-slate-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default YoutubeConverter;
