
import React from 'react';
import { Zap, CheckCircle2, Globe, Rocket, Users, ShieldCheck, ArrowRight, Instagram, Search, Award } from 'lucide-react';
import { APP_NAME, APP_SLOGAN } from '../constants';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="bg-slate-50 overflow-hidden">
      {/* Nav */}
      <nav className="max-w-7xl mx-auto px-6 py-8 flex justify-between items-center relative z-10">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-indigo-900 rounded-lg flex items-center justify-center font-serif italic text-white text-xl shadow-xl">E</div>
          <span className="text-2xl font-bold tracking-tight text-slate-900 uppercase">{APP_NAME}</span>
        </div>
        <button 
          onClick={onStart}
          className="px-6 py-2 bg-indigo-900 text-white rounded-full font-semibold hover:bg-indigo-800 transition-all shadow-md"
        >
          Acessar Plataforma
        </button>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-16 pb-24 text-center relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-indigo-200/20 blur-3xl rounded-full -z-10" />
        
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 text-indigo-700 rounded-full text-sm font-bold mb-8 uppercase tracking-widest">
          <Award className="w-4 h-4" />
          <span>Liderança em Estética Digital</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 mb-6 leading-tight max-w-5xl mx-auto">
          Transforme sua clínica em <br />
          <span className="text-indigo-600">autoridade no Google</span>
        </h1>
        
        <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed">
          O conteúdo automático feito para estética. Seja encontrada por quem busca procedimentos, eduque seu cliente e venda sem depender de dancinhas no Instagram.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
          <button 
            onClick={onStart}
            className="px-10 py-5 bg-indigo-900 text-white rounded-2xl font-bold text-lg hover:bg-indigo-950 transition-all shadow-2xl hover:-translate-y-1 flex items-center gap-3"
          >
            Começar agora
            <ArrowRight className="w-5 h-5" />
          </button>
          <p className="text-sm font-medium text-slate-500 italic">"Deixe seu blog trabalhar por você."</p>
        </div>

        <img 
          src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&q=80&w=1200" 
          className="rounded-3xl shadow-2xl border-8 border-white mx-auto max-w-5xl w-full h-[500px] object-cover"
          alt="Clínica de Estética"
        />
      </section>

      {/* Por que Blog Section */}
      <section className="bg-white py-24 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-slate-900 mb-6">Por que toda clínica precisa de um Blog?</h2>
              <div className="space-y-6">
                {[
                  { title: "Patrimônio Digital", desc: "Diferente do Instagram (alugado), o blog é seu patrimônio. Ele gera tráfego todos os dias.", icon: <Globe className="text-indigo-600" /> },
                  { title: "Confiança e Autoridade", desc: "Conteúdo denso educa o cliente e reduz objeções antes mesmo da avaliação.", icon: <Award className="text-indigo-600" /> },
                  { title: "Vendedor 24h", desc: "Seu blog trabalha enquanto sua clínica atende, atraindo leads qualificados no Google.", icon: <Zap className="text-indigo-600" /> }
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1">{item.icon}</div>
                    <div>
                      <h4 className="font-bold text-slate-900">{item.title}</h4>
                      <p className="text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-indigo-900 p-8 rounded-3xl text-white shadow-2xl">
              <h3 className="text-2xl font-bold mb-6">A Dor Real da Estética</h3>
              <ul className="space-y-4">
                <li className="flex gap-3 items-start opacity-80">
                  <span className="text-rose-400 font-bold">✕</span>
                  <span>Falta de tempo para criar conteúdos profundos.</span>
                </li>
                <li className="flex gap-3 items-start opacity-80">
                  <span className="text-rose-400 font-bold">✕</span>
                  <span>Dependência escrava de redes sociais e algoritmos.</span>
                </li>
                <li className="flex gap-3 items-start opacity-80">
                  <span className="text-rose-400 font-bold">✕</span>
                  <span>Conteúdo raso que não converte procedimentos de alto ticket.</span>
                </li>
                <li className="flex gap-3 items-start opacity-80">
                  <span className="text-rose-400 font-bold">✕</span>
                  <span>Invisibilidade total nas buscas do Google.</span>
                </li>
              </ul>
              <div className="mt-8 p-6 bg-white/10 rounded-2xl border border-white/20">
                <p className="font-medium italic">"Instagram = aluguel. Blog = patrimônio."</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">A Máquina de Autoridade Estética</h2>
          <p className="text-slate-600">O Elevare Content AI faz tudo no piloto automático.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { title: "180 Artigos/Ano", desc: "Fluxo contínuo de conteúdos alinhados à estética moderna sem você escrever uma linha.", icon: "✍️" },
            { title: "SEO Avançado", desc: "Título, meta description e headings automáticos. Compatível com Yoast e Rank Math.", icon: "🔍" },
            { title: "Web Stories", desc: "Transforme artigos em visual stories que dominam as buscas mobile e o Google Discover.", icon: "📱" },
            { title: "Artigos em Áudio", desc: "Acessibilidade e alcance. Player de áudio automático para seus posts.", icon: "🎙️" },
            { title: "Links Inteligentes", desc: "A IA cria conexões internas entre seus posts para fortalecer sua relevância.", icon: "🔗" },
            { title: "Imagens IA", desc: "Geração de imagens luxuosas e profissionais em um clique para cada artigo.", icon: "✨" }
          ].map((f, i) => (
            <div key={i} className="bg-white p-8 rounded-2xl border border-slate-200 hover:border-indigo-300 transition-all hover:shadow-xl">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{f.title}</h3>
              <p className="text-sm text-slate-600">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Publico Alvo Section */}
      <section className="bg-slate-900 py-24 text-white">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16">
          <div className="space-y-6">
            <h3 className="text-3xl font-bold border-b border-indigo-500 pb-4">É para você se...</h3>
            <ul className="space-y-4">
              <li className="flex gap-3 items-center">
                <CheckCircle2 className="text-emerald-500" />
                <span>Você é esteticista, fisio ou dona de clínica.</span>
              </li>
              <li className="flex gap-3 items-center">
                <CheckCircle2 className="text-emerald-500" />
                <span>Busca previsibilidade de agendamentos.</span>
              </li>
              <li className="flex gap-3 items-center">
                <CheckCircle2 className="text-emerald-500" />
                <span>Quer ser a referência nº 1 na sua região.</span>
              </li>
            </ul>
          </div>
          <div className="space-y-6">
            <h3 className="text-3xl font-bold border-b border-rose-500 pb-4">Não é para você se...</h3>
            <ul className="space-y-4 opacity-60">
              <li className="flex gap-3 items-center text-slate-400">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Quer resultados imediatos sem constância.</span>
              </li>
              <li className="flex gap-3 items-center text-slate-400">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Vive apenas de "trends" passageiras.</span>
              </li>
              <li className="flex gap-3 items-center text-slate-400">
                <span className="text-rose-500 font-bold">✕</span>
                <span>Não valoriza a construção de autoridade real.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 text-center px-6">
        <h2 className="text-4xl font-bold text-slate-900 mb-6">Deixe seu blog trabalhar por você.</h2>
        <p className="text-xl text-slate-600 mb-10 max-w-xl mx-auto">
          Elevare Editorial AI: Não é uma ferramenta de texto. É um sistema de construção de autoridade digital.
        </p>
        <button 
          onClick={onStart}
          className="px-12 py-6 bg-indigo-900 text-white rounded-2xl font-bold text-xl hover:bg-indigo-950 transition-all shadow-2xl flex items-center gap-4 mx-auto"
        >
          Começar agora
          <Rocket className="w-6 h-6" />
        </button>
      </section>

      <footer className="bg-slate-100 py-12 px-6 border-t border-slate-200">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-900 rounded flex items-center justify-center font-bold text-white">E</div>
            <span className="font-bold uppercase tracking-widest">{APP_NAME}</span>
          </div>
          <p className="text-slate-500 text-sm">© 2024 {APP_NAME}. Ética, Autoridade e Tecnologia.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
