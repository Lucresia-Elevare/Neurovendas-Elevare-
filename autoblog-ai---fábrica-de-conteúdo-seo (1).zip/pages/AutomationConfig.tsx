
import React, { useState } from 'react';
import { Calendar, Zap, Settings, ShieldCheck, Clock, RefreshCw, CheckCircle2 } from 'lucide-react';

const AutomationConfig: React.FC = () => {
  const [active, setActive] = useState(true);
  const [postsPerWeek, setPostsPerWeek] = useState(3);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Piloto Automático</h1>
          <p className="text-slate-500">Configure sua máquina de autoridade digital.</p>
        </div>
        <div className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm ${active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
          <div className={`w-2 h-2 rounded-full ${active ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
          {active ? 'Sistema Ativo' : 'Pausado'}
        </div>
      </header>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
            <Calendar className="w-6 h-6 text-indigo-600" />
            <h3 className="font-bold text-lg">Calendário Editorial</h3>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Frequência de Posts</label>
              <div className="grid grid-cols-3 gap-2">
                {[1, 3, 7].map(n => (
                  <button 
                    key={n}
                    onClick={() => setPostsPerWeek(n)}
                    className={`py-3 rounded-xl border font-bold text-sm transition-all ${postsPerWeek === n ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                  >
                    {n}x / semana
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-500 uppercase">Próximo Slot Livre</span>
                <span className="text-xs font-mono text-indigo-600">Quarta-feira, 09:00</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-500 uppercase">Auto-Publicar</span>
                <button 
                  onClick={() => setActive(!active)}
                  className={`w-10 h-5 rounded-full relative transition-colors ${active ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${active ? 'right-1' : 'left-1'}`} />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-indigo-900 p-8 rounded-3xl text-white shadow-xl space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-white/10">
            <Settings className="w-6 h-6 text-indigo-300" />
            <h3 className="font-bold text-lg">Critérios de Inteligência</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <ShieldCheck className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <h4 className="font-bold text-sm">Filtro Médio-Científico</h4>
                <p className="text-xs text-indigo-200">Todo artigo passa por validação semântica baseada em termos da SBD.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <h4 className="font-bold text-sm">Atualização Semanal</h4>
                <p className="text-xs text-indigo-200">Seu blog nunca fica mais de 3 dias sem uma nova atualização de autoridade.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <RefreshCw className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <h4 className="font-bold text-sm">Retroalimentação de Links</h4>
                <p className="text-xs text-indigo-200">Artigos novos linkam automaticamente para os antigos e vice-versa.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <h3 className="font-bold text-slate-900 mb-6 uppercase text-xs tracking-widest">Cronograma de Autoridade</h3>
        <div className="grid grid-cols-7 gap-4">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'].map((day, i) => (
            <div key={i} className="space-y-2 text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase">{day}</span>
              <div className={`aspect-square rounded-2xl flex items-center justify-center border-2 transition-all ${[1, 3, 5].includes(i) ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'border-slate-100 text-slate-200'}`}>
                {[1, 3, 5].includes(i) ? <Zap className="w-5 h-5 fill-current" /> : <div className="w-2 h-2 rounded-full bg-slate-100" />}
              </div>
            </div>
          ))}
        </div>
      </div>

      <button className="w-full py-5 bg-indigo-900 text-white rounded-2xl font-bold text-lg hover:shadow-2xl transition-all">
        Salvar Configurações do Piloto Automático
      </button>
    </div>
  );
};

export default AutomationConfig;
