
import React, { useState, useRef } from 'react';
import { 
  Sparkles, 
  Loader2, 
  Save, 
  Send, 
  RefreshCw, 
  Volume2, 
  Globe, 
  FileVideo, 
  BookOpen, 
  Link as LinkIcon, 
  CheckCircle2, 
  ChevronRight, 
  BrainCircuit, 
  Play, 
  Pause,
  Zap
} from 'lucide-react';
import { generateBlogContent, generateImage, generateAudio } from '../services/geminiService';
import { ArticleType } from '../types';

// Funções auxiliares para decodificação de áudio PCM (conforme diretrizes do Gemini API)
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const ArticleGenerator: React.FC = () => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    keyword: '',
    topic: '',
    type: ArticleType.PROCEDURE,
    size: '1000 palavras',
    language: 'Português',
    projectId: ''
  });

  const [generatedArticle, setGeneratedArticle] = useState<any>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  
  // Ref para controlar a reprodução de áudio
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setGeneratedImage(null);
    setGeneratedArticle(null);
    audioBufferRef.current = null;
    setIsPlaying(false);
    
    try {
      const content = await generateBlogContent(formData);
      setGeneratedArticle(content);
      setStep(2);
      
      if (content && content.title) {
        const img = await generateImage(content.title);
        setGeneratedImage(img);
      }
    } catch (err) {
      alert("Erro ao gerar conteúdo estético.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const stopAudio = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch (e) {
        // Ignorar se já estiver parado
      }
      sourceNodeRef.current = null;
    }
    setIsPlaying(false);
  };

  const playDecodedBuffer = (buffer: AudioBuffer) => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    
    source.onended = () => {
      setIsPlaying(false);
      sourceNodeRef.current = null;
    };

    source.start(0);
    sourceNodeRef.current = source;
    setIsPlaying(true);
  };

  const handleAudioAction = async () => {
    if (!generatedArticle) return;

    // Se já estiver tocando, para
    if (isPlaying) {
      stopAudio();
      return;
    }

    // Se já temos o buffer decodificado, apenas toca
    if (audioBufferRef.current) {
      playDecodedBuffer(audioBufferRef.current);
      return;
    }

    // Caso contrário, gera o áudio
    setIsAudioLoading(true);
    try {
      const base64Audio = await generateAudio(generatedArticle.content);
      
      if (base64Audio) {
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        
        const audioBytes = decodeBase64(base64Audio);
        const buffer = await decodeAudioData(audioBytes, audioContextRef.current, 24000, 1);
        
        audioBufferRef.current = buffer;
        
        // Alerta de sucesso solicitado pelo usuário
        alert("Resumo em áudio gerado com sucesso! Iniciando a leitura.");
        
        playDecodedBuffer(buffer);
      } else {
        alert("Não foi possível gerar o áudio no momento.");
      }
    } catch (err) {
      console.error("Erro ao gerar áudio:", err);
      alert("Ocorreu um erro ao processar o resumo em áudio.");
    } finally {
      setIsAudioLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500 pb-20">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 mb-2">Editorial AI</h1>
        <p className="text-slate-500">Inteligência semântica e autoridade digital em estética.</p>
      </header>

      {step === 1 && (
        <div className="bg-white p-10 rounded-3xl border border-slate-200 shadow-xl max-w-3xl mx-auto">
          <div className="grid gap-6 mb-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Palavra-chave Principal</label>
              <input 
                type="text" 
                placeholder="Ex: Benefícios dos Bioestimuladores, Criomodelagem vs Lipo..."
                className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                value={formData.keyword}
                onChange={e => setFormData({...formData, keyword: e.target.value})}
              />
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Abordagem Editorial</label>
                <select 
                  className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.type}
                  onChange={e => setFormData({...formData, type: e.target.value as ArticleType})}
                >
                  <option value={ArticleType.PROCEDURE}>Guia de Procedimento</option>
                  <option value={ArticleType.AUTHORITY}>Artigo de Autoridade</option>
                  <option value={ArticleType.EDUCATIONAL}>Educativo (Ciência Aplicada)</option>
                  <option value={ArticleType.MANAGEMENT}>Gestão e Mercado</option>
                  <option value={ArticleType.NEWS}>Tendências Internacionais</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Extensão do Conteúdo</label>
                <select 
                  className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.size}
                  onChange={e => setFormData({...formData, size: e.target.value})}
                >
                  <option>800 palavras (Otimizado)</option>
                  <option>1200 palavras (Pilar)</option>
                  <option>2000 palavras (Guia Definitivo)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-start gap-4">
              <div className="p-2 bg-indigo-600 rounded-lg text-white">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <div className="text-xs text-indigo-700 leading-relaxed">
                <strong>Link Intelligence:</strong> Nossa IA analisará o seu Hub de URLs e identificará os melhores textos-âncora para maximizar seu SEO sem parecer artificial.
              </div>
            </div>
          </div>

          <button 
            onClick={handleGenerate}
            disabled={loading || !formData.keyword}
            className="w-full py-5 bg-indigo-900 text-white rounded-2xl font-bold text-xl hover:bg-indigo-950 transition-all flex items-center justify-center gap-3 disabled:opacity-50 shadow-xl"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Sparkles className="w-6 h-6" />}
            {loading ? "Processando Semântica..." : "Gerar com Link Intelligence"}
          </button>
        </div>
      )}

      {step === 2 && generatedArticle && (
        <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
          <div className="bg-white/80 backdrop-blur-md p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4 sticky top-20 z-10">
            <div className="flex gap-2">
              <button onClick={() => { stopAudio(); setStep(1); }} className="px-5 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold transition-colors">Voltar</button>
              <button onClick={handleGenerate} disabled={loading} className="px-5 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold flex items-center gap-2 hover:bg-slate-200 transition-colors">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                Regerar
              </button>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={handleAudioAction} 
                disabled={isAudioLoading}
                className={`px-5 py-2 rounded-xl font-bold flex items-center gap-2 transition-colors ${isPlaying ? 'bg-indigo-600 text-white animate-pulse' : 'bg-violet-100 text-violet-700 hover:bg-violet-200'}`}
              >
                {isAudioLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : (isPlaying ? <Pause className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />)}
                {isPlaying ? "Parar Áudio" : "Resumo em Áudio"}
              </button>
              <button className="px-5 py-2 bg-indigo-900 text-white rounded-xl font-bold flex items-center gap-2 shadow-lg hover:bg-indigo-950 transition-all">
                <Send className="w-4 h-4" /> Publicar no Blog
              </button>
            </div>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            <div className="lg:col-span-3 space-y-6">
               <div className="bg-white p-10 rounded-3xl border border-slate-200 shadow-sm prose prose-indigo max-w-none">
                  <header className="mb-10">
                    <div className="flex items-start justify-between gap-6 mb-4">
                      <h1 className="text-4xl font-extrabold text-slate-900 leading-tight flex-1">{generatedArticle.title}</h1>
                      <button 
                        onClick={handleAudioAction}
                        disabled={isAudioLoading}
                        className={`p-4 rounded-full transition-all flex-shrink-0 shadow-lg ${isPlaying ? 'bg-indigo-600 text-white animate-pulse' : 'bg-indigo-100 text-indigo-600 hover:bg-indigo-200'}`}
                        title={isPlaying ? "Parar áudio" : "Ouvir áudio do artigo"}
                      >
                        {isAudioLoading ? <Loader2 className="w-7 h-7 animate-spin" /> : (isPlaying ? <Pause className="w-7 h-7 fill-current" /> : <Play className="w-7 h-7 fill-current" />)}
                      </button>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <span className="flex items-center gap-1 bg-slate-100 px-3 py-1 rounded-full"><BookOpen className="w-4 h-4 text-indigo-500" /> {formData.type}</span>
                      <span className="flex items-center gap-1 bg-emerald-50 px-3 py-1 rounded-full text-emerald-700"><Globe className="w-4 h-4" /> SEO: Otimizado</span>
                      {isPlaying && <span className="text-indigo-600 font-bold animate-bounce flex items-center gap-1"><Volume2 className="w-3 h-3" /> Reproduzindo áudio...</span>}
                    </div>
                  </header>
                  
                  <div className="relative mb-12">
                    {!generatedImage ? (
                      <div className="w-full aspect-video bg-slate-50 border-2 border-dashed border-slate-200 animate-pulse rounded-3xl flex flex-col items-center justify-center text-slate-400">
                        <Loader2 className="w-10 h-10 animate-spin mb-4" />
                        <span className="font-bold uppercase tracking-widest text-[10px]">Gerando Imagem Editorial de Alta Qualidade...</span>
                      </div>
                    ) : (
                      <div className="group relative">
                        <img 
                          src={generatedImage} 
                          className="w-full aspect-video object-cover rounded-3xl shadow-2xl border border-slate-100 transition-transform duration-500 group-hover:scale-[1.01]" 
                          alt="Article Cover" 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-3xl pointer-events-none" />
                      </div>
                    )}
                  </div>
                  
                  <div 
                    className="article-body-content text-slate-700 text-lg leading-relaxed space-y-4"
                    dangerouslySetInnerHTML={{ __html: generatedArticle.content }}
                  />
               </div>
            </div>

            <div className="space-y-6">
               <div className="bg-indigo-900 p-6 rounded-3xl text-white shadow-xl">
                  <div className="flex items-center gap-2 mb-4">
                    <BrainCircuit className="w-5 h-5 text-indigo-300" />
                    <h3 className="font-bold text-lg">Link Intelligence</h3>
                  </div>
                  <div className="space-y-4">
                    {generatedArticle.linkIntelligence?.map((item: any, i: number) => (
                      <div key={i} className="bg-white/10 p-4 rounded-xl border border-white/10">
                        <div className="flex items-center gap-2 mb-1">
                          <LinkIcon className="w-3 h-3 text-emerald-400" />
                          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-200">Âncora: "{item.anchor}"</span>
                        </div>
                        <p className="text-xs text-indigo-50 leading-tight mb-2">{item.reason}</p>
                        <span className="text-[9px] font-mono text-indigo-300 break-all">{item.url}</span>
                      </div>
                    ))}
                    {!generatedArticle.linkIntelligence?.length && (
                       <p className="text-xs text-indigo-300 italic">Nenhum link foi inserido automaticamente neste artigo.</p>
                    )}
                  </div>
               </div>

               <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                  <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2 uppercase text-xs tracking-widest">
                    Metadata SEO
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Title Tag</span>
                      <p className="text-sm text-slate-800 font-semibold leading-tight">{generatedArticle.metaTitle}</p>
                    </div>
                    <div>
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Meta Description</span>
                      <p className="text-xs text-slate-600 leading-relaxed">{generatedArticle.metaDescription}</p>
                    </div>
                  </div>
               </div>

               <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200">
                  <h3 className="font-bold text-slate-900 mb-4 text-xs uppercase tracking-widest">Distribuição</h3>
                  <div className="space-y-2">
                    <button className="w-full py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-slate-100 transition-all">
                      <FileVideo className="w-4 h-4 text-emerald-600" /> Criar Web Story
                    </button>
                    <button className="w-full py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-slate-100 transition-all">
                      <Zap className="w-4 h-4 text-amber-500 fill-current" /> Enviar para Pinterest
                    </button>
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ArticleGenerator;
