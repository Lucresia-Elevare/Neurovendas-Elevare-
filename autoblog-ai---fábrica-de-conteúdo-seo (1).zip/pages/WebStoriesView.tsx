
import React, { useState } from 'react';
import { Video, Sparkles, Loader2, ChevronRight, ChevronLeft, Send, Smartphone } from 'lucide-react';
import { generateWebStoryData } from '../services/geminiService';

const WebStoriesView: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [story, setStory] = useState<any>(null);
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleGenerateStory = async () => {
    setLoading(true);
    try {
      // Exemplo fixo para demonstração, na integração real viria do artigo selecionado
      const data = await generateWebStoryData(
        "Benefícios da Criomodelagem", 
        "A criomodelagem é um procedimento não invasivo..."
      );
      setStory(data);
    } catch (e) {
      alert("Erro ao gerar Story");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900">Web Stories AI</h1>
          <p className="text-slate-500">Transforme posts longos em experiências visuais para mobile.</p>
        </div>
        <button 
          onClick={handleGenerateStory}
          disabled={loading}
          className="px-6 py-3 bg-indigo-900 text-white rounded-2xl font-bold flex items-center gap-2 hover:bg-indigo-950 transition-all shadow-lg disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          Gerar Novo Story
        </button>
      </header>

      {!story ? (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-20 text-center space-y-4">
          <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mx-auto">
            <Video className="w-10 h-10 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">Nenhum Story Criado</h3>
            <p className="text-slate-500 max-w-xs mx-auto">Clique em gerar para converter seu último artigo em um formato dinâmico para o Google Discover.</p>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Mobile Preview */}
          <div className="relative mx-auto w-[300px] h-[600px] bg-slate-900 rounded-[3rem] border-[8px] border-slate-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-20 h-4 bg-slate-800 rounded-full z-20" />
            
            <div className="relative flex-1 bg-slate-800 overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80 z-10" />
              <img 
                src={`https://picsum.photos/seed/${currentSlide}/600/1200`} 
                className="absolute inset-0 w-full h-full object-cover opacity-80"
                alt="Story Slide"
              />
              
              <div className="absolute top-8 left-0 right-0 px-4 flex gap-1 z-20">
                {story.slides.map((_: any, i: number) => (
                  <div key={i} className="flex-1 h-1 rounded-full overflow-hidden bg-white/20">
                    <div className={`h-full bg-white transition-all duration-300 ${i === currentSlide ? 'w-full' : i < currentSlide ? 'w-full' : 'w-0'}`} />
                  </div>
                ))}
              </div>

              <div className="absolute bottom-10 left-6 right-6 z-20 space-y-2">
                <h4 className="text-xl font-black text-white leading-tight">{story.slides[currentSlide].title}</h4>
                <p className="text-sm text-slate-200 line-clamp-3">{story.slides[currentSlide].text}</p>
              </div>
            </div>

            <div className="absolute inset-y-0 left-0 w-1/4 z-30" onClick={() => setCurrentSlide(Math.max(0, currentSlide - 1))} />
            <div className="absolute inset-y-0 right-0 w-1/4 z-30" onClick={() => setCurrentSlide(Math.min(story.slides.length - 1, currentSlide + 1))} />
          </div>

          {/* Controls & Details */}
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-indigo-600" />
                Estrutura do Story
              </h3>
              <div className="space-y-4">
                {story.slides.map((slide: any, i: number) => (
                  <button 
                    key={i}
                    onClick={() => setCurrentSlide(i)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all ${i === currentSlide ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 border-transparent hover:bg-white hover:border-slate-200'}`}
                  >
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mb-1">Slide {i + 1}</span>
                    <p className="text-sm font-bold text-slate-800">{slide.title}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <button className="flex-1 py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-xl hover:bg-slate-800 transition-all">
                <Send className="w-5 h-5" /> Publicar no Blog
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WebStoriesView;
