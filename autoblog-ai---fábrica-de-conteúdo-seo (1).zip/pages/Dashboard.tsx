
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, FileText, CheckCircle, Award, Zap, Users, Search } from 'lucide-react';
import { ICON_STYLES } from '../constants';

const data = [
  { name: 'Jan', autoridade: 40, agendamentos: 10 },
  { name: 'Fev', autoridade: 55, agendamentos: 18 },
  { name: 'Mar', autoridade: 50, agendamentos: 25 },
  { name: 'Abr', autoridade: 75, agendamentos: 42 },
  { name: 'Mai', autoridade: 85, agendamentos: 38 },
  { name: 'Jun', autoridade: 95, agendamentos: 55 },
];

const Dashboard: React.FC = () => {
  const stats = [
    { label: 'Artigos no Ar', value: '42', icon: <FileText className={ICON_STYLES} />, color: 'bg-indigo-100 text-indigo-600' },
    { label: 'Nível de Autoridade', value: 'Platina', icon: <Award className={ICON_STYLES} />, color: 'bg-amber-100 text-amber-600' },
    { label: 'Web Stories Ativos', value: '18', icon: <Zap className={ICON_STYLES} />, color: 'bg-violet-100 text-violet-600' },
    { label: 'Buscas no Google', value: '8.4k', icon: <Search className={ICON_STYLES} />, color: 'bg-emerald-100 text-emerald-600' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard de Autoridade Elevare</h1>
          <p className="text-slate-500">Monitorando o crescimento da sua clínica digital.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-indigo-900 text-white rounded-xl font-semibold hover:bg-indigo-800 transition-all flex items-center gap-2">
            <Zap className="w-4 h-4 fill-current" />
            Novo Post
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-2 rounded-xl ${stat.color}`}>{stat.icon}</div>
              <span className="text-xs font-bold text-emerald-600">+15%</span>
            </div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-600" />
            Evolução de Tráfego Orgânico
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorAuth" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                   contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="autoridade" stroke="#4f46e5" strokeWidth={4} fillOpacity={1} fill="url(#colorAuth)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Status da Clínica</h3>
          <div className="space-y-6">
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-xs font-bold text-slate-400 uppercase mb-2">Blog Conectado</p>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500 rounded flex items-center justify-center text-white font-bold">W</div>
                <p className="font-bold text-slate-700">estetica-premium.com.br</p>
              </div>
            </div>
            
            <div className="p-4 bg-indigo-900 text-white rounded-2xl shadow-lg">
              <p className="text-xs font-bold text-indigo-300 uppercase mb-2">Próxima Publicação</p>
              <p className="font-bold mb-1">Criomodelagem: Guia Definitivo</p>
              <p className="text-xs text-indigo-200">Agendado para amanhã, às 09:00</p>
            </div>

            <div className="space-y-2">
               <div className="flex justify-between text-xs font-bold text-slate-500 uppercase">
                  <span>Créditos de Autoridade</span>
                  <span>142/180</span>
               </div>
               <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-600 w-[78%] transition-all duration-1000" />
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
