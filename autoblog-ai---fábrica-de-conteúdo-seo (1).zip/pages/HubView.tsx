
import React, { useState } from 'react';
import { 
  Table, 
  Database, 
  RefreshCw, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  Search,
  Filter,
  MoreVertical,
  Link as LinkIcon,
  Image as ImageIcon,
  Volume2,
  Share2,
  Zap
} from 'lucide-react';
import { HubRow, ArticleType } from '../types';

const INITIAL_ROWS: HubRow[] = [
  { id: '1', keyword: 'Criomodelagem avançada', topic: 'Corporal', type: ArticleType.PROCEDURE, status: 'Publicado', seoScore: 98, channels: { blog: true, pinterest: true, linkedin: true, audio: true } },
  { id: '2', keyword: 'Harmonização Facial Natural', topic: 'Facial', type: ArticleType.AUTHORITY, status: 'Otimizado', seoScore: 92, channels: { blog: false, pinterest: true, linkedin: false, audio: true } },
  { id: '3', keyword: 'Gestão de Clínicas 2024', topic: 'Business', type: ArticleType.MANAGEMENT, status: 'Gerado', seoScore: 85, channels: { blog: false, pinterest: false, linkedin: false, audio: false } },
  { id: '4', keyword: 'Bioestimuladores de Colágeno', topic: 'Facial', type: ArticleType.PROCEDURE, status: 'Pendente', seoScore: 0, channels: { blog: false, pinterest: false, linkedin: false, audio: false } },
  { id: '5', keyword: 'Ética na Estética', topic: 'Educação', type: ArticleType.EDUCATIONAL, status: 'Erro', seoScore: 0, channels: { blog: false, pinterest: false, linkedin: false, audio: false } },
];

const HubView: React.FC = () => {
  const [rows, setRows] = useState<HubRow[]>(INITIAL_ROWS);
  const [isSyncing, setIsSyncing] = useState(false);

  const syncWithSheets = () => {
    setIsSyncing(true);
    setTimeout(() => setIsSyncing(false), 2000);
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'Publicado': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Erro': return 'bg-rose-100 text-rose-700 border-rose-200';
      case 'Pendente': return 'bg-slate-100 text-slate-700 border-slate-200';
      default: return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-6 h-6 text-indigo-600" />
            Hub Central Operacional
          </h1>
          <p className="text-slate-500">Google Sheets como Single Source of Truth</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={syncWithSheets}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-all shadow-sm"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-indigo-600' : ''}`} />
            Sincronizar Sheets
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-900 text-white rounded-xl font-bold hover:bg-indigo-950 transition-all shadow-md">
            <Play className="w-4 h-4 fill-current" />
            Rodar Automação
          </button>
        </div>
      </header>

      {/* Stats Hub */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-xs font-bold text-slate-400 uppercase mb-1">Status da Planilha</p>
          <div className="flex items-center gap-2 text-emerald-600 font-bold">
            <CheckCircle2 className="w-4 h-4" /> Conectado (v2.4)
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-xs font-bold text-slate-400 uppercase mb-1">Gatilhos Apps Script</p>
          <div className="flex items-center gap-2 text-indigo-600 font-bold">
            <Zap className="w-4 h-4 fill-current" /> 3 Gatilhos Ativos
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-xs font-bold text-slate-400 uppercase mb-1">Links Analisados</p>
          <div className="flex items-center gap-2 text-slate-900 font-bold">
             <LinkIcon className="w-4 h-4 text-indigo-600" /> 24 URLs Mapeadas
          </div>
        </div>
      </div>

      {/* Table Interface */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg w-full max-w-xs">
            <Search className="w-4 h-4 text-slate-400" />
            <input type="text" placeholder="Buscar no hub..." className="bg-transparent text-sm outline-none w-full" />
          </div>
          <button className="p-2 text-slate-500 hover:bg-white rounded-lg transition-colors">
            <Filter className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Procedimento / Keyword</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">SEO</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest text-center">Multicanal</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-900">{row.keyword}</p>
                    <p className="text-xs text-slate-500">{row.topic} • {row.type}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold border uppercase ${getStatusStyle(row.status)}`}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-12 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div className={`h-full ${row.seoScore > 90 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${row.seoScore}%` }} />
                      </div>
                      <span className="text-xs font-bold text-slate-600">{row.seoScore || '-'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-3">
                      <LinkIcon className={`w-4 h-4 ${row.channels.blog ? 'text-indigo-600' : 'text-slate-200'}`} />
                      <ImageIcon className={`w-4 h-4 ${row.channels.pinterest ? 'text-rose-500' : 'text-slate-200'}`} />
                      <Share2 className={`w-4 h-4 ${row.channels.linkedin ? 'text-blue-600' : 'text-slate-200'}`} />
                      <Volume2 className={`w-4 h-4 ${row.channels.audio ? 'text-violet-500' : 'text-slate-200'}`} />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <button className="p-2 hover:bg-white rounded-lg border border-transparent hover:border-slate-200 transition-all">
                      <MoreVertical className="w-4 h-4 text-slate-400" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Logs Section */}
      <div className="bg-slate-900 rounded-2xl p-6 text-slate-300 font-mono text-xs space-y-2 border border-slate-800 shadow-2xl">
        <p className="text-slate-500 mb-4 font-bold border-b border-slate-800 pb-2 flex items-center gap-2">
           <AlertCircle className="w-3 h-3" /> Logs de Execução em Tempo Real
        </p>
        <p><span className="text-emerald-500">[SUCCESS]</span> 2024-05-20 14:02:11: Hub sincronizado via Google Apps Script.</p>
        <p><span className="text-indigo-400">[INFO]</span> 2024-05-20 14:05:00: Analisando links internos para 'Criomodelagem'. 3 links encontrados.</p>
        <p><span className="text-emerald-500">[SUCCESS]</span> 2024-05-20 14:06:22: Artigo gerado com 2 links internos e 1 externo (PubMed).</p>
        <p><span className="text-amber-500">[WARNING]</span> 2024-05-20 14:06:23: Pinterest API retornou delay, agendado re-try para 10min.</p>
      </div>
    </div>
  );
};

export default HubView;
